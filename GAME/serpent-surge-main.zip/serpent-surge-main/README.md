# Serpent Surge
## Description
**Serpent Surge** is a demonstration project for the practical part of the Nix DevOps workshops. The candidates need to work on this project, to improve their practical skills after the theoretical parts.
## Forking the directory
For working with this repository in the future, you'll need to fork the repository.
1. At the upper-right corner, click on the *Fork* button
2. Name can be the same
3. If needed, choose *Copy the main branch only* option
4. Click on *Create fork*

In the future, make every necessary change to your fork.
## Note
Before starting to work on the project, check the code and try to understand what is the purpose of each component.
## Contact
In case of questions about this project, you can reach me at the following e-mail address:

Mate Torma: mate.torma@nixs.com